const { randomJoke, randomTen } = require('./handler');

console.log('randomJoke', randomJoke());
console.log('randomTen', randomTen());
